require 'named_object'

class Supplier
  include NamedObject
end
