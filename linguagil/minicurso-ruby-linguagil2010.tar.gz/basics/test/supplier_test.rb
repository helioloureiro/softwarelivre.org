require 'test/unit'
require 'supplier'

class SupplierTest < Test::Unit::TestCase

  def test_supplier_name
    supplier = Supplier.new
    supplier.name = "Extra"
    assert_equal "Extra", supplier.name
  end

end
