class Evaluator
  def self.eval_formula(spreadsheet, formula)
    for evaluator in [Reference.new, Sum.new]
      if evaluator.recognizes?(formula)
        return evaluator.eval(spreadsheet, formula)
      end
    end
  end
end

class Reference
  def recognizes?(formula)
    formula =~ /^[A-Z][0-9]$/
  end
  def eval(spreadsheet, formula)
    spreadsheet.eval(formula)
  end
end

class Sum
  def recognizes?(formula)
    formula =~ /^[A-Z][0-9]\+[A-Z][0-9]$/
  end
  def eval(spreadsheet, formula)
    cells = formula.split('+')
    spreadsheet.eval(cells[0]) + spreadsheet.eval(cells[1])
  end
end

class Spreadsheet

  def initialize
    @cells = {}
  end

  def read(cell)
    @cells[cell]
  end

  def write(cell, text)
    @cells[cell] = text
  end

  def eval(cell)
    text = read(cell)
    if text.nil?
      nil
    else
      if text[0] == "="[0]
        evaluator = Evaluator.eval_formula(self, text[1..-1])
      else
        text.to_i
      end
    end
  end

end
