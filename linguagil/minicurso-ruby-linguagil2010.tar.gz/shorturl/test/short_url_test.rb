require 'test/unit'
require 'short_url'

class ShortUrlTest < Test::Unit::TestCase
  def test_shorten_one_url
    short_url = ShortUrl.new
    new_url = short_url.add('http://boipeba.dyndns.org/~terceiro/linguagil/shorturl/')
    assert_equal 'a', new_url
    assert_equal 'http://boipeba.dyndns.org/~terceiro/linguagil/shorturl/', short_url.get('a')
  end

  def test_two_urls
    short_url = ShortUrl.new
    short_url.add('http://site1.com/')

    new_url = short_url.add('http://site2.com/')
    assert_equal 'b', new_url
    assert_equal 'http://site2.com/', short_url.get('b')
  end

  def test_duplicate_url
    short_url = ShortUrl.new
    code = short_url.add('http://site1.com/')
    assert_equal code, short_url.add('http://site1.com/')
  end
end
