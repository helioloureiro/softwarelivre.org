require 'test/unit'
require 'spreadsheet'

class TestSpreadsheet < Test::Unit::TestCase
  
  def setup
    @spreadsheet = Spreadsheet.new
  end

  def test_create_spreadsheet
    assert @spreadsheet != nil
  end

  def test_empty_spredsheet
    assert_equal nil, @spreadsheet.read('A1')
  end

  def test_writing
    @spreadsheet.write('A1', '10')
    assert_equal '10', @spreadsheet.read('A1')
  end

  def test_eval_constant
    @spreadsheet.write('A1', '10')
    assert_equal 10, @spreadsheet.eval('A1')
  end

  def test_eval_empty_cell
    assert_equal nil, @spreadsheet.eval('B10')
  end

  def test_cell_reference
    @spreadsheet.write('A1', '10')
    @spreadsheet.write('A2', '=A1')
    assert_equal 10, @spreadsheet.eval('A2')
  end
  
  def test_formula_sum
    @spreadsheet.write('A1', '2')
    @spreadsheet.write('A2', '3')
    @spreadsheet.write('A3', '=A1+A2')
    assert_equal 5, @spreadsheet.eval('A3')
  end

end
