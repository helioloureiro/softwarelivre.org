require 'test/unit'

class DataTypesTest < Test::Unit::TestCase
  
  def test_empty_hash
    hash = {}
    assert_equal nil, hash['value']
  end        
  
  def test_hash_with_default_value
    hash = Hash.new(0)
    assert_equal 0, hash['value']
  end

  def test_hash_access
    hash = { 'name' => 'LinguAgil', 'date' => '2010-09-16', 1 => 'Um' }
    assert_equal 'LinguAgil', hash['name']
    assert_equal '2010-09-16', hash['date']
    assert_equal 'Um', hash[1]
  end

  def test_hash_write
    hash = {}
    hash['name'] = 'LinguAgil'
    assert_equal 'LinguAgil', hash['name']
  end

  def test_symbol
    sym1 = :this_is_a_symbol
    sym2 = :this_is_a_symbol
    str1 = "this is a string"
    str2 = "this is a string"

    assert_equal sym1.object_id, sym2.object_id

    assert_equal str1, str2
    assert_not_equal str1.object_id, str2.object_id
  end

  def test_regular_expression
    assert('terceiro@colivre.coop.br' =~ /\w+@\w+/)
    assert('email-invalido' !~ /\w+@\w+/)
  end

  def test_true
    assert(!false)
    assert(!nil)
    assert(0)
    assert([])
    assert({})
    assert(true)
    assert("")
  end

  def test_numbers_are_objects
    assert_equal "10", 10.to_s
    assert_equal Fixnum, 10.class
    assert_equal Integer, Fixnum.superclass
    assert_equal Integer, Bignum.superclass
    assert_equal Class, Fixnum.class
    assert_equal Class, String.class
    assert_equal Object, Class.superclass.superclass
  end
  
  protected

  def auxiliar_method_1
    # this is protected
  end

  private

  def auxiliar_method_2
    # this is private
  end

end
