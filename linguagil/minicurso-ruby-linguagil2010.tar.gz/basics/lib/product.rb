require 'named_object'

class Product

  def initialize
    Product.count = Product.count + 1
  end

  def self.count
    @count || 0
  end
  def self.count=(value)
    @count = value
  end

  include NamedObject
  
  def
    NamedObject::Validator.new
  end
end
