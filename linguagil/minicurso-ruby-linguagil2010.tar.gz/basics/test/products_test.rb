require 'test/unit'
require 'product'

class ProductTest < Test::Unit::TestCase

  def test_product_name
    product = Product.new
    product.name = "Smartphone running Android"

    assert_equal "Smartphone running Android", product.name
  end

  def test_product_count
    n1 = Product.count
    Product.new
    Product.new
    assert_equal n1 + 2, Product.count
  end

end
