module NamedObject

  class Validator
  end

  def name=(value)
    @name = value
  end
  def name
    @name
  end
end
