class ShortUrl

  def initialize
    @database = {}
    @reverse = {}
    @code = 'a'
  end

  def add(url)
    if @reverse[url]
      @reverse[url]
    else
      @database[@code] = url
      @reverse[url] = @code
      last_code = @code
      @code = @code.next
      last_code
    end
  end

  def get(code)
    @database[code]
  end

end
